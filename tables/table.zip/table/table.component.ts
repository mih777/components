import { Component, OnInit } from '@angular/core';
import { UserService, User } from '../../user.service';

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.scss']
})
export class TableComponent implements OnInit {

  users: User[] = []

  constructor(private service: UserService){}

  ngOnInit(){
    this.getUsers()
  }

  getUsers(){
    this.service.getUsers()
      .subscribe(res => {
        this.users = res
        console.log(this.users)
      })
  }

}
